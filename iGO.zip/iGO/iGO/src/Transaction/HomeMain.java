package Transaction;

public class HomeMain
{

	public static void main(String[] args)
	{
		HomeScreen homescreen = new HomeScreen();
		homescreen.mainPage();
	}
}
