package Transaction;

import java.util.HashMap;

public class Ticket {

	private HashMap<String, Double> value = new HashMap<>();
	
	public Ticket()
	{
		value.put("Daily Pass", 11.00);
		value.put("Ten Pass", 32.50);
		value.put("Two Way Pass", 6.50);
		value.put("Weekend Pass", 15.00);
		value.put("One Way Pass", 3.25);
	}
	
	public HashMap<String, Double> getValue()
	{
		return value;
	}
	
	public void setValue(HashMap<String, Double> value)
	{
		this.value = value;
	}
}
