package Transaction;

public class Bank {

		public static boolean validateCardNumber(String cardNumber) {
		    try {
		    	double temp = Double.parseDouble(cardNumber);
		    }catch(Exception e) {
		    	return false;
		    }
			int sum = 0;
		    boolean alternate = false;
		    for (int i = cardNumber.length() - 1; i >= 0; i--) {
		        int n = Integer.parseInt(cardNumber.substring(i, i + 1));
		        if (alternate) {
		            n *= 2;
		            if (n > 9) {
		                n = (n % 10) + 1;
		            }
		        }
		        sum += n;
		        alternate = !alternate;
		    }
		   
		    if (sum % 10 == 0) {
	            System.out.println(cardNumber + " is a valid card number\n");
	            return true;
	        } else {
	            System.out.println(cardNumber + " is NOT a valid card number\n");
	        }
	        return false;
		}
}
