package Transaction;

public class Traveller 
{
    int cash = 0;
	
	public int getCash()
	{
		return cash;
	}
	
	public Card getCard()
	{
		return card;
	}
	
	public void setCard(Card card)
	{
		this.card = card;
	}
	
	Card card = new Card();
}
