package Transaction;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomeScreen implements ActionListener 
{
	Ticket ticket = new Ticket();
	Traveller traveller = new Traveller();
	Card card = new Card();
    Bank bank = new Bank();
    EmailValidation email = new EmailValidation();
    RechargeCard rechargecard = new RechargeCard();
    
    String trip = "";
	double price;
	
	JPanel panel = new JPanel(new GridLayout(ticket.getValue().size(),1,8,8));
    JTextField textField =  new JTextField();
    JFrame frame = new JFrame("IGO-TVM");
    
    public void mainPage()
    {
        ImageIcon icon = new ImageIcon("iGO/assets/icon.jpg");
        frame.setIconImage(icon.getImage());
    
    	textField.setText("");
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(400,300));

        panel.setBorder(new EmptyBorder(new Insets(60, 80, 60, 80)));
        panel.setBorder(new EmptyBorder(new Insets(40, 80, 40, 80)));
        
        JButton j1 = new JButton("Purchase a new Ticket");
        JButton j2 = new JButton("Recharge Card");
        
        panel.add(j1);
        panel.add(j2);
        
        j1.addActionListener(this);
        j2.addActionListener(this);
        
        frame.setContentPane(panel);
        Color bgColor = new Color(255, 165, 0);
        frame.getContentPane().setBackground(bgColor);
        frame.pack();
        frame.setVisible(true);
       
    }
    
    public void init()
    {
    	
    	panel.removeAll();
        textField.setText("");
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
        panel.setBorder(new EmptyBorder(new Insets(120, 160, 120, 160)));
        panel.setBorder(new EmptyBorder(new Insets(45, 90, 40, 90)));

        JButton j1 = new JButton("Daily Pass - 11$");
        JButton j2 = new JButton("Ten Pass - 32.50$");
        JButton j3 = new JButton("Two Way Pass - 6.50$");
        JButton j4 = new JButton("Weekend Pass - 15$");
        JButton j5 = new JButton("One Way Pass - 3.25$");

        panel.add(j1);
        panel.add(j2);
        panel.add(j3);
        panel.add(j4);
        panel.add(j5);
        
        j1.addActionListener(this);
        j2.addActionListener(this);
        j3.addActionListener(this);
        j4.addActionListener(this);
        j5.addActionListener(this);
       
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true); 
    }
    
    public void rechargeCard()
    {
    	panel.removeAll();
    	textField.setText("");
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
        panel.setBorder(new EmptyBorder(new Insets(120, 160, 120, 160)));
        panel.setBorder(new EmptyBorder(new Insets(45, 90, 40, 90)));

        JButton j1 = new JButton("Monthly - 56.50$");
        JButton j2 = new JButton("Ten Tap - 32.50$");
      
        panel.add(j1);
        panel.add(j2);
        
        j1.addActionListener(this);
        j2.addActionListener(this);
       
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true); 
    }
    public void paymentMethod(String a)
    {
        
    	 textField.setText("");
         JFrame.setDefaultLookAndFeelDecorated(true);
         frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


         panel.setBorder(new EmptyBorder(new Insets(120, 160, 120, 160)));
         panel.setBorder(new EmptyBorder(new Insets(45, 90, 40, 90)));

         JButton j1 = new JButton("Submit Card");
         JButton j2 = new JButton("Submit Cash");
         panel.add(j1);
         panel.add(j2);
         
        
         j1.addActionListener(this);
         j2.addActionListener(this);
        
         frame.setContentPane(panel);
         frame.pack();
         frame.setVisible(true);
         
         
    }

    public void paymentMethodCard(String a)
    {    
    	panel.removeAll();
        JLabel label1 = new JLabel("..Enter your Debit/Credit card number..:");
        panel.add(label1);
        panel.add(textField);
     
        JButton submitCard = new JButton("Submitt Card");
        submitCard.addActionListener(this);

        JButton back = new JButton("Back");
        back.addActionListener(this);

        panel.add(submitCard);
        panel.add(back);

        panel.revalidate();
        panel.repaint();
    }
    
    public void paymentMethodCash(String a)
    {
 
        panel.removeAll();
        textField.setText("");
        JLabel label1 = new JLabel(".......Insert Your Cash......:");
        panel.add(label1);
        panel.add(textField);
        
        JButton submitCash = new JButton("Submitt Cash");
        submitCash.addActionListener(this);

        JButton back = new JButton("Back");
        back.addActionListener(this);

        panel.add(submitCash);
        panel.add(back);

        panel.revalidate();
        panel.repaint();   
    }
     
    public void receiptMethod(){
        panel.removeAll();

        JButton email = new JButton("Email Receipt");
        email.addActionListener(this);

        JButton paper = new JButton("Paper Receipt");
        paper.addActionListener(this);

        panel.add(email);
        panel.add(paper);

        panel.revalidate();
        panel.repaint();
    }
    

	private void emailValidate() 
	{
		panel.removeAll();
		textField.setText("");
        JLabel label1 = new JLabel("Enter your Emailid:");
        panel.add(label1);
        panel.add(textField);
        
        JButton Done = new JButton("Done");
        Done.addActionListener(this);

        JButton back = new JButton("Back");
        back.addActionListener(this);

        panel.add(Done);
        panel.add(back);

        panel.revalidate();
        panel.repaint();
	}
    
	@Override
    public void actionPerformed(ActionEvent a) 
    {
    	String b = a.getActionCommand();
    	if(b.equals("Purchase a new Ticket"))
    	{
    		init();

    	}
    	else if(b.equals("Recharge Card"))
    	{
    		rechargeCard();
    	}
    	else if(b.equals("Submit Card"))
    	{
    		paymentMethodCard(b);
    	}
    	else if(b.equals("Submit Cash"))
    	{
    		paymentMethodCash(b);
    	}
    	else if(b.equals("Back"))
    	{
    		panel.removeAll();
            panel.revalidate();
            panel.repaint();
            mainPage();
    	}
    	else if(b.equals("Submitt Cash"))
    	{
    		double temp = 0;
    		try 
    		{
    			temp = Double.parseDouble(textField.getText());
    			if(temp < price)
        		{
        			JOptionPane.showMessageDialog(frame, "Insufficient, cash");
        		}
                else if(temp > price)
                {
                	JOptionPane.showMessageDialog(frame, "Here is your change : "+(temp-price));
                	receiptMethod();
                }
        		else
        		{
        			receiptMethod();
        		}
    			
    		}
    		catch(NumberFormatException e) 
    		{
    			JOptionPane.showMessageDialog(frame, "Please enter cash");
//    			panel.removeAll();
//                panel.revalidate();
//                panel.repaint();
//    			paymentMethodCash(b);
    			
    		}
            

    	}
    	else if(b.equals("Submitt Card"))
    	{
            if(!Bank.validateCardNumber(textField.getText()))
     		{
     			JOptionPane.showMessageDialog(frame, "Invalid Card Number");
     		}
     		else
    		{
     			receiptMethod();
    		}
    	}
    	else if(b.equals("Email Receipt"))
    	{
    		
    		emailValidate();
    		
    	}
    	else if(b.equals("Done"))
    	{
    		if(!EmailValidation.isValidEmail(textField.getText()))
    		{
    			JOptionPane.showMessageDialog(frame, "Invalid Email Adress");
    		}
    		else
    		{
    			JOptionPane.showMessageDialog(frame, "Receipt generated");
                JOptionPane.showMessageDialog(frame, "Ticket printed");
                panel.removeAll();
                panel.revalidate();
                panel.repaint();
                mainPage();
    		}
    	}
    	else if(b.equals("Paper Receipt"))
    	{
    		JOptionPane.showMessageDialog(frame, "Receipt generated");
            JOptionPane.showMessageDialog(frame, "Ticket printed");
            panel.removeAll();
            panel.revalidate();
            panel.repaint();
            mainPage();
    	}
    	else
    	{
    		 panel.removeAll();
    		 System.out.println(a.getActionCommand());
    		 trip = a.getActionCommand().split(" -")[0];
    		 
             System.out.println(trip);
             if(trip.contains("Pass"))
             {
       
            	 price = ticket.getValue().get(trip);
             }
             else
             {
            	 price = rechargecard.getValue().get(trip);
             }
             System.out.println(price);
    		 paymentMethod(b);
    	}
    }

}