package Transaction;

import java.util.HashMap;

public class RechargeCard 
{
private HashMap<String, Double> value = new HashMap<>();
	
	public RechargeCard()
	{
		value.put("Monthly", 56.50);
		value.put("Ten Tap", 32.50);
	}
	
	public HashMap<String, Double> getValue()
	{
		return value;
	}
	
	public void setValue(HashMap<String, Double> value)
	{
		this.value = value;
	}
}
