package Transaction;


import javax.swing.*;
import javax.swing.border.EmptyBorder;

import iGO.Ticket;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Scanner;

public class HomeScreen implements ActionListener {
	Ticket ticket = new Ticket();
	
	JPanel panel = new JPanel(new GridLayout(ticket.getValue().size(),1,8,8));
    JTextField textField =  new JTextField();
    JFrame frame = new JFrame("IGO-TVM");

    public void init(){
        textField.setText("");
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


        panel.setBorder(new EmptyBorder(new Insets(120, 160, 120, 160)));
        panel.setBorder(new EmptyBorder(new Insets(45, 90, 40, 90)));

        JButton jb1 = new JButton("Daily Pass - 11$");
        JButton jb2 = new JButton("Ten Pass - 32.50$");
        JButton jb3 = new JButton("Two Way - 6.50$");
        JButton jb4 = new JButton("Weekend Pass - 15$");

        panel.add(jb1);
        panel.add(jb2);
        panel.add(jb3);
        panel.add(jb4);
        
        jb1.addActionListener(this);
        jb2.addActionListener(this);
        jb3.addActionListener(this);
        jb4.addActionListener(this);
       
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
    }

}
