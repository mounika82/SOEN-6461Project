package Transaction;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class HomeMain 
{
	public static void main(String[] args)
	{
	        HomeScreen homescreen = new HomeScreen();

	        homescreen.init();
	}
}
