package Transaction;

public class Card
{
      String cardNumber;

    public String getCardNumber() 
    {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }
}
