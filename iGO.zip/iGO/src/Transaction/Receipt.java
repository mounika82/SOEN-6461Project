package Transaction;

public class Receipt {

}
