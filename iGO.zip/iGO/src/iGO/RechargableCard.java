package iGO;

public class RechargableCard {

	Passenger p;
	int pin;

	boolean checkPin(int pin) {
		if (pin == p.pin) {
			return true;
		}
		return false;

	}

}
