package iGO;

public class Passenger {

	public int pin;
}
