package iGO;

import java.util.HashMap;

public class Ticket {

	private HashMap<String, Double> value = new HashMap<>();
	
	public Ticket()
	{
		value.put("DailyPass", (double) 11);
		value.put("TenPass", 32.50);
		value.put("TwoWay", 6.50);
		value.put("Weekend Pass", (double) 15);
	}
	
	public HashMap<String, Double> getValue()
	{
		return value;
	}
	
	public void setValue(HashMap<String, Double> value)
	{
		this.value = value;
	}
}
