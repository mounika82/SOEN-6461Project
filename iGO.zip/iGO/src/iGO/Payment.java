package iGO;

public class Payment {

}
